Survey data, 2024.
