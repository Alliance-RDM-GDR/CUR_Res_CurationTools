import csv
from pathlib import Path
import argparse

def open_as_csv(file_path:Path, mode:str='r', newline:str='', encoding:str='utf-8'):
    """
    Creates and returns a CSV reader or writer handler based on the supplied file path.  Returns a csv.reader by default.
    
    :param file_path: File to open as a CSV for reading or writing
    :type file_path: Path
    :param mode: The mode to open the file in, uses open() modes. Use 'w' to return a csv.writer handler.  Defaults to 'r'
    :type mode: str
    :param newline: What character to use as a newline, defaults to ''
    :type newline: str
    :param encoding: What character encoding to use when creating the handler, defaults to 'utf-8'
    :type encoding: str
    """
    if not file_path.parent.exists():
        print(f"Parent directory \"{file_path.parent.as_posix()}\" doesn't exist, creating path...")
        file_path.parent.mkdir(parents=True)

    try:
        file_handler = open(file_path.as_posix(), mode, newline=newline, encoding=encoding)

        if mode == 'r':
            csv_handler = csv.reader(file_handler)
        elif mode == 'w':
            csv_handler = csv.writer(file_handler)

        return csv_handler
    
    except FileNotFoundError:
        print(f"Error: The file '{file_path.as_posix()}' was not found.")
    except Exception as ex:
        print(f"An unexpected error occured: {ex}")
    
    return False

# Splits the CTD casts into two files, one containing the metadata and one containing the data.
def parse_ctd(source_file:Path, metadata_file:Path, data_file:Path): 
    """
    Splits the CTD files around the empty row between the metadata and headers
    
    :param source_file: Input path for source CTD file with metadata headers
    :type source_file: Path
    :param metadata_file: Output path for metadata file
    :type metadata_file: Path
    :param data_file: Output path for metadata file
    :type data_file: Path
    """
    source_reader = open_as_csv(source_file)

    meta_writer = open_as_csv(metadata_file, mode='w')
    data_writer = open_as_csv(data_file, mode='w')

    #flag for switching between files
    empty_row = False

    for row in source_reader:
        #check if row is empty
        if not any(row):
            empty_row = True
            continue

        if not empty_row:
            meta_writer.writerow(row)

        else:
            data_writer.writerow(row)

    print(f"Successfully split '{source_file.as_posix()}' into Metadata and Data files.")
    print(f" - Metadata: {metadata_file.as_posix()}")
    print(f" - Data: {data_file.as_posix()}\n")


if __name__ == "__main__":
    cli_raw_args = argparse.ArgumentParser()

    cli_raw_args.add_argument(
        'source_file',
        help="The path and filename to be parsed.  This can be a directory of files to parse instead of a single file with the use of the --batch option.",
    )

    cli_raw_args.add_argument(
        "-g",
        "--batch",
        help="Indicates that the source file is a directory of files to be parsed.",
        action="store_true",
    )

    cli_raw_args.add_argument(
        "-d",
        "--data_path",
        help="Alternate sub-directory to output data file. Default: same directory as source file '.'",
        action="store",
        default='.'
    )

    cli_raw_args.add_argument(
        "-m",
        "--meta_path",
        help="Alternate sub-directory to output metadata file. Default: same directory as source file '.'",
        action="store",
        default='.'
    )

    cli_raw_args.add_argument(
        "-s",
        "--data_file_suffix",
        help="Added to the end of the data filename after parsing. Inserted before file extension. Default: '_Data'",
        action="store",
        default='_Data'
    )

    cli_raw_args.add_argument(
        "-n",
        "--meta_file_suffix",
        help="Added to the end of the metadata filename after parsing. Inserted before file extension. Default: '_Metadata'",
        action="store",
        default='_Metadata'
    )

    # Parse command line arguments
    prog_args = cli_raw_args.parse_args()
    
    source_file = Path(prog_args.source_file)

    if not prog_args.batch and not source_file.is_dir():
        if not source_file.exists():
            print(f"Source file \"{source_file.as_posix()}\" not found.")

        else:
            data_file = Path(source_file.parent).joinpath(prog_args.data_path, (f"{source_file.stem}{prog_args.data_file_suffix}{source_file.suffix}"))
            meta_file = Path(source_file.parent).joinpath(prog_args.meta_path, (f"{source_file.stem}{prog_args.meta_file_suffix}{source_file.suffix}"))

            print(f"Processing \"{source_file.as_posix()}\" into \"{meta_file.as_posix()}\" and \"{data_file.as_posix()}\"...")
            
            parse_ctd(source_file=source_file, metadata_file=meta_file, data_file=data_file)

    elif prog_args.batch:
        print("Processing Directory of files...")

        try:
            for file in source_file.iterdir():
                data_file = Path(file.parent).joinpath(prog_args.data_path, (f"{file.stem}{prog_args.data_file_suffix}{file.suffix}"))
                meta_file = Path(file.parent).joinpath(prog_args.meta_path, (f"{file.stem}{prog_args.meta_file_suffix}{file.suffix}"))
                
                print(f"Processing \"{file.as_posix()}\" into \"{meta_file.as_posix()}\" and \"{data_file.as_posix()}\"...")

                parse_ctd(source_file=file, metadata_file=meta_file, data_file=data_file)

        except FileNotFoundError:
            print(f"\nERROR: The specified path \"{source_file.as_posix()}\" is not a valid directory.")

    elif source_file.is_dir():
        print("Source is a directory and not a file, to process a directory use the '--batch' option or specify an individual file for processing.")

